# TipTime
A Tip Calculator App that tips someone for Great Service
